package com.customers.customer2;

import com.intelligid.packaging.custom.IntelliGIDLicense;

public class License implements IntelliGIDLicense {

	@Override
	public String getInstallationDateYYYYMMDD() {
		return "2013-11-01";
	}

	@Override
	public String getSupportPlanStartYYYYMMDD() {
		return "2013-11-01";
	}

	@Override
	public String getSupportPlanEndYYYYMMDD() {
		return "2019-11-01";
	}

	@Override
	public String getCustomerName() {
		return "Customer 2";
	}
	
	@Override
	public String getCustomerCode() {
		return "customer2";
	}

}