package com.customers.customer1.plugin.somePlugin;

public class Customer1Plugin {

}
