package com.customers.customer1;

import com.intelligid.packaging.custom.IntelliGIDLicense;

public class License implements IntelliGIDLicense {

	@Override
	public String getInstallationDateYYYYMMDD() {
		return "2014-11-01";
	}

	@Override
	public String getSupportPlanStartYYYYMMDD() {
		return "2014-11-01";
	}

	@Override
	public String getSupportPlanEndYYYYMMDD() {
		return "2015-11-01";
	}

	@Override
	public String getCustomerName() {
		return "Customer 1";
	}
	
	@Override
	public String getCustomerCode() {
		return "customer1";
	}
}