package ca.customers.customer3;

import com.intelligid.packaging.custom.IntelliGIDLicense;

public class License implements IntelliGIDLicense {

	@Override
	public String getInstallationDateYYYYMMDD() {
		return "2014-10-01";
	}

	@Override
	public String getSupportPlanStartYYYYMMDD() {
		return "2014-10-01";
	}

	@Override
	public String getSupportPlanEndYYYYMMDD() {
		return "2015-10-01";
	}

	@Override
	public String getCustomerName() {
		return "Customer 3";
	}
	
	@Override
	public String getCustomerCode() {
		return "customer3";
	}

}
