package ca.customers.customer3;

public class Customer3Plugin {

}
