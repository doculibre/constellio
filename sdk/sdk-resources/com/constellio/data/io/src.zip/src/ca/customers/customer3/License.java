package ca.customers.customer3;

import com.intelligid.packaging.custom.IntelliGIDLicense;


public class License implements IntelliGIDLicense {

	@Override
	public String getInstallationDate_YYYY_MM_DD() {
		return "2014-10-01";
	}

	@Override
	public String getSupportPlanStart_YYYY_MM_DD() {
		return "2014-10-01";
	}

	@Override
	public String getSupportPlanEnd_YYYY_MM_DD() {
		return "2015-10-01";
	}

	@Override
	public String getCustomerName() {
		return "Customer 3";
	}

}
