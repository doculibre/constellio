package com.customers.customer2;

import com.intelligid.packaging.custom.IntelliGIDLicense;

public class License implements IntelliGIDLicense {

	@Override
	public String getInstallationDate_YYYY_MM_DD() {
		return "2013-11-01";
	}

	@Override
	public String getSupportPlanStart_YYYY_MM_DD() {
		return "2013-11-01";
	}

	@Override
	public String getSupportPlanEnd_YYYY_MM_DD() {
		return "2019-11-01";
	}

	@Override
	public String getCustomerName() {
		return "Customer 2";
	}

}