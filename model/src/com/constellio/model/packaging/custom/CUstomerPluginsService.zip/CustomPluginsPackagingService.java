package com.intelligid.packaging.custom;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.intelligid.io.FileService;
import com.intelligid.io.IOServices;
import com.intelligid.io.ZipService;
import com.intelligid.io.ZipServiceException;

public class CustomPluginsPackagingService {

	public static final String CUSTOMER_CODE = "getCustomerCode()";
	public static final String CUSTOMER_NAME = "getCustomerName()";
	public static final String INSTALLATION_DATE = "getInstallationDate_YYYY_MM_DD()";
	public static final String SUPPORT_PLAN_START = "getSupportPlanStart_YYYY_MM_DD()";
	public static final String SUPPORT_PLAN_END = "getSupportPlanEnd_YYYY_MM_DD()";
	
	private FileService fileService;
	private ZipService zipService;
	
	public CustomPluginsPackagingService() {
		this.fileService = new FileService();
		this.zipService = new ZipService(new IOServices());
	}
	
	public CustomPluginsPackagingService(FileService fileService, ZipService zipService) {
		this.fileService = fileService;
		this.zipService = zipService;
	}

	public void buildJars(File sourceFolder, File binFolder, File jarsDestinationFolder) {
		for (Customer customer : detectCustomers(sourceFolder)) {
			buildCustomerJar(customer, binFolder, jarsDestinationFolder);
		}
	}
	
	public List<Customer> detectCustomers(File sourceFolder) {
		List<Customer> customers = new ArrayList<Customer>();
		for (File licenseFile : fileService
				.listRecursiveFilesWithName(sourceFolder, "License.java")) {
			customers.add(buildCustomerFromLicense(licenseFile));
		}
		return customers;

	}
	
	public Customer buildCustomerFromLicense(File licenseFile) {
		String licenseContent = fileService.readFileToStringWithoutExpectableIOException(licenseFile);
		
		String code = extractLicenseAttribute(licenseFile, licenseContent, CUSTOMER_CODE);
		String name = extractLicenseAttribute(licenseFile, licenseContent, CUSTOMER_NAME);
		String thePackage = extractLicensePackage(licenseFile, licenseContent);
		Date installationDate = extractLicenseDateAttribute(licenseFile, licenseContent, INSTALLATION_DATE);
		Date supportPlanStart = extractLicenseDateAttribute(licenseFile, licenseContent, SUPPORT_PLAN_START);
		Date supportPlanEnd = extractLicenseDateAttribute(licenseFile, licenseContent, SUPPORT_PLAN_END);
		
		return new Customer(code, name, thePackage, installationDate, supportPlanStart, supportPlanEnd);
	}

	public void buildCustomerJar(Customer customer, File binFolder, File jarDestinationFolder) {
		
		File customerJar = new File(jarDestinationFolder, "intelligid-" + customer.getCustomerCode() + ".jar");
		
		File tempFolder = null;
		try {
		String customerPackagePath = customer.getCustomerPackage().replace(".", File.separator);
		tempFolder = fileService.newTemporaryFolderWithoutExpectableIOException();
		File classPackage = new File(binFolder, customerPackagePath);
		File clientWorkPackage = new File(tempFolder, customerPackagePath);
		clientWorkPackage.mkdirs();
		fileService.copyDirectoryWithoutExpectableIOException(classPackage, clientWorkPackage);
		System.out.println(tempFolder.getAbsolutePath());
		try {
			zipService.zip(customerJar, Arrays.asList(tempFolder.listFiles()));
		} catch (ZipServiceException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		} finally {
			fileService.deleteDirectoryWithoutExpectableIOException(tempFolder);
		}

	}
	

	public String extractLicenseAttribute(File licenseFile, String theLicenseContent, String method) {
		List<String> lines = Arrays.asList(theLicenseContent.split("\n"));
		int index = 0;
		for(int i =0 ; i < lines.size(); i++) {
			String line = lines.get(i);
			if (line.contains(method)) {
				index = i;
			}
		}
		String value = lines.get(index + 1).replace("\t", "").trim();
		if (!value.startsWith("return \"") || !value.endsWith("\";")) {
			throw new CustomPluginsPackagingServiceException.MethodCannotBeParsed(licenseFile, method);
		} else {
			return value.replace("return \"", "").replace("\";", "");
		}
	}

	public String extractLicensePackage(File licenseFile, String theLicenseContent) {
		List<String> lines = Arrays.asList(theLicenseContent.split("\n"));
		int index = 0;
		for(int i =0 ; i < lines.size(); i++) {
			String line = lines.get(i);
			if (line.startsWith("package")) {
				index = i;
			}
		}
		return lines.get(index).replace("package ", "").replace(";", "").trim();
	}

	public Date extractLicenseDateAttribute(File licenseFile, String theLicenseContent, String method) {
		String value = extractLicenseAttribute(licenseFile, theLicenseContent, method);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			return sdf.parse(value);
		} catch (ParseException e) {
			throw new CustomPluginsPackagingServiceException.InvalidDate(licenseFile, method);
		}
	}

	 
	
}
