package com.intelligid.packaging.custom;

import java.util.Date;


public class Customer {

	private final String customerCode;
	
	private final String customerName;
	
	private final String customerPackage;
	
	private final Date installationDate;
	
	private final Date installationStart;
	
	private final Date installationEnd;

	public Customer(String customerCode, String customerName, String customerPackage,
			Date installationDate, Date installationStart, Date installationEnd) {
		super();
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerPackage = customerPackage;
		this.installationDate = installationDate;
		this.installationStart = installationStart;
		this.installationEnd = installationEnd;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getCustomerPackage() {
		return customerPackage;
	}

	public Date getInstallationDate() {
		return installationDate;
	}

	public Date getInstallationStart() {
		return installationStart;
	}

	public Date getInstallationEnd() {
		return installationEnd;
	}
	
	
}
